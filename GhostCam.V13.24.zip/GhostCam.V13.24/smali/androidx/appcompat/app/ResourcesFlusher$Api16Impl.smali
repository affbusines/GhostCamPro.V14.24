.class Landroidx/appcompat/app/ResourcesFlusher$Api16Impl;
.super Ljava/lang/Object;
.source "ResourcesFlusher.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/app/ResourcesFlusher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "Api16Impl"
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 215
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 217
    return-void
.end method

.method static clear(Landroid/util/LongSparseArray;)V
    .registers 1
    .param p0, "longSparseArray"    # Landroid/util/LongSparseArray;

    .line 221
    invoke-virtual {p0}, Landroid/util/LongSparseArray;->clear()V

    .line 222
    return-void
.end method
